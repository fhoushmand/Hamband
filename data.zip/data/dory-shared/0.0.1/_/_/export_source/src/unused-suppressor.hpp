#pragma once

namespace dory {

template <typename... T>
void IGNORE(T&&...) {}

}  // namespace dory
