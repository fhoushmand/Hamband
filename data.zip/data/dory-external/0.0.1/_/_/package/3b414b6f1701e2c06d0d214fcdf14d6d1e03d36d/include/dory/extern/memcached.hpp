#pragma once

#include <libmemcached/memcached.h>